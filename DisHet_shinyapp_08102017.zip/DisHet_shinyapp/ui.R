library(shiny)

shinyUI(pageWithSidebar(
  
  # Application title
  headerPanel("DisHet User Interface"),

    sidebarPanel(
      downloadButton("downloadExp_T", "Example exp_T"),
      downloadButton("downloadExp_N", "Example exp_N"),
      downloadButton("downloadExp_G", "Example exp_G"),
      hr(),
      fileInput("file1","Upload un-logged gene expression in bulk RNA-seq samples (exp_T):"), 
      fileInput("file2","Upload un-logged gene expression in the corresponding normal samples (exp_N):"),
      fileInput("file3","Upload un-logged gene expression in the corresponding tumor samples (exp_G):"),
      hr(), 
      textInput("n_cycle_i", "Number of MCMC iterations:", 500),
      textInput("mean_last_i", "Length of stablized iterations:", 50),
      textInput("initial_rho_S_i", "Initial Stroma Proportion:", 0.02),
      textInput("initial_rho_G_i", "Initial Tumor Proportion:", 0.96),
      textInput("initial_rho_N_i", "Initial Normal Proportion:", 0.02),
      hr(), 
      actionButton("run", "Run"),
      width =2),

    mainPanel(
      width = 10,
      helpText(   a("Click Here to Download DisHet R package Documentation", target="_blank",     href="https://cran.r-project.org/web/packages/DisHet/DisHet.pdf")),
      p(paste("Dissection of bulk sample gene expression using matched normal and tumorgraft RNA-seq data:")),
      hr(),
      plotOutput("plot1"),
      downloadButton("downloadplot1", "Download the histogram"), 
      downloadButton("downloadtable1", "Download the table of proportion estimates"),
      tags$br(),
      tags$hr(),
      plotOutput("plot2"),
      downloadButton("downloadplot2", "Download the heatmap"),
      downloadButton("downloadtable2", "Download the table of gene expression estimates in Stroma component")
    )
))