library(shiny)
library(DisHet)
library("RColorBrewer")
library("gplots")
library(ggplot2)
library(gridExtra)
load("DisHet_App_example.RData")



shinyServer(function(input,output){
  data_T <- reactiveValues(data = exp_T)
  data_N <- reactiveValues(data = exp_N)
  data_G <- reactiveValues(data = exp_G)
  
  observeEvent(input$run, {
    file1 <- input$file1
    if(!is.null(file1)){data_T$data <- read.table(file1$datapath, header=TRUE, sep=",", row.names=1)}
    file2 <- input$file2
    if(!is.null(file2)){data_N$data <- read.table(file2$datapath, header=TRUE, sep=",", row.names=1)}
    file3 <- input$file3
    if(!is.null(file3)){data_G$data <- read.table(file3$datapath, header=TRUE, sep=",", row.names=1)} 
  })
  
  rho <- reactive({
    exp_T <- data_T$data
    exp_N <- data_N$data
    exp_G <- data_G$data
    ## dim(rho)= 3 by # patients
    if(is.null(exp_T)|is.null(exp_N)|is.null(exp_G)){
      rho <- NULL
    }else{
      exp_T <- data.matrix(data_T$data)
      exp_N <- data.matrix(data_N$data)
      exp_G <- data.matrix(data_G$data)
      n_cycle_i <- as.numeric(input$n_cycle_i)
      mean_last_i <- as.numeric(input$mean_last_i)
      initial_rho_S_i <- as.numeric(input$initial_rho_S_i)
      initial_rho_G_i <- as.numeric(input$initial_rho_G_i)
      initial_rho_N_i <- as.numeric(input$initial_rho_N_i)
      rho <- DisHet(exp_T, exp_N, exp_G, save=FALSE, n_cycle=n_cycle_i, mean_last=mean_last_i, initial_rho_S=initial_rho_S_i,initial_rho_G=initial_rho_G_i,initial_rho_N=initial_rho_N_i)
    }
    return(rho)
  })
  
  S <- reactive({
    exp_T <- data_T$data
    exp_N <- data_N$data
    exp_G <- data_G$data
    rho <- rho()
    ## dim(S) = # genes by # patients
    if(is.null(exp_T)|is.null(exp_N)|is.null(exp_G)|is.null(rho)){
      S <- NULL
    }else{
      exp_T <- data.matrix(data_T$data)
      exp_N <- data.matrix(data_N$data)
      exp_G <- data.matrix(data_G$data)
      rho <- data.matrix(rho())
      S <- StromaExp(exp_T,exp_N,exp_G, rho)
    }
    return(S)
  })
  
  
  output$downloadtable1 <- downloadHandler(
    filename = function() {
      paste('Proportion', '.csv', sep='')
    },
    content = function(file) {
      rho <- rho()
      if(!is.null(rho)){write.csv(rho, file)}
    }
  )
  
  output$downloadtable2 <- downloadHandler(
    filename = function() {
      paste('StromaExp', '.csv', sep='')
    },
    content = function(file) {
      S <- S()
      if(!is.null(S)){write.csv(S, file)}
    }
  )
  
  output$plot1 <- renderPlot({
    if (is.null(rho())) { return() }
    rho <- data.frame(t(rho()))
    names(rho) <- c("Tumor_Perc", "Normal_Perc","Stroma_Perc")
    p1 <- ggplot(rho, aes(x=Tumor_Perc)) + 
      geom_histogram(aes(y = ..density..), color="black", fill=NA) +
      geom_density(color="blue")
    
    p2 <- ggplot(rho, aes(x=Normal_Perc)) + 
      geom_histogram(aes(y = ..density..), color="black", fill=NA) +
      geom_density(color="blue")
    
    p3 <- ggplot(rho, aes(x=Stroma_Perc)) + 
      geom_histogram(aes(y = ..density..), color="black", fill=NA) +
      geom_density(color="blue")
  
    grid.arrange(p1, p2, p3, nrow = 1)
    }
  )
  
  output$downloadplot1 <- downloadHandler(
    filename = function() {
      paste('rho', 'png', sep = ".")
    },
    content <- function(file) {
      png(file)
      
      if (is.null(rho())) { return() }
      rho <- data.frame(t(rho()))
      names(rho) <- c("Tumor_Perc", "Normal_Perc","Stroma_Perc")
      p1 <- ggplot(rho, aes(x=Tumor_Perc)) + 
        geom_histogram(aes(y = ..density..), color="black", fill=NA) +
        geom_density(color="blue")
      
      p2 <- ggplot(rho, aes(x=Normal_Perc)) + 
        geom_histogram(aes(y = ..density..), color="black", fill=NA) +
        geom_density(color="blue")
      
      p3 <- ggplot(rho, aes(x=Stroma_Perc)) + 
        geom_histogram(aes(y = ..density..), color="black", fill=NA) +
        geom_density(color="blue")
      
      plot <- grid.arrange(p1, p2, p3, nrow = 1) 
      print(plot)
      dev.off()
    },
    contentType = "image/png"
  )
  
  output$plot2 <- renderPlot({
    if (is.null(S())) { return() }
    S <- S()
    heatmap.2(t(as.matrix(S)), col = bluered(100),srtRow=45,srtCol=45,trace="none", margins=c(5, 5))
  }
  )
  
  output$downloadplot2 <- downloadHandler(
    filename = function() {
      paste('StromaExp', 'png', sep = ".")
    },
    content = function(file) {
      png(file)
      
      if (is.null(S())) { return() }
      S <- S()
      plot <- heatmap.2(t(as.matrix(S)), col = bluered(100),srtRow=45,srtCol=45,trace="none", margins=c(5, 5))
      print(plot)
      dev.off()
    },
    contentType = "image/png"
  )
  
  output$downloadExp_T <- downloadHandler(
    filename = function() {
      paste('exp_T', '.csv', sep='')
    },
    content = function(file) {
      exp_T <- data_T$data
      if(!is.null(exp_T)){write.csv(exp_T, file)}
    }
  )
  
  output$downloadExp_N <- downloadHandler(
    filename = function() {
      paste('exp_N', '.csv', sep='')
    },
    content = function(file) {
      exp_N <- data_N$data
      if(!is.null(exp_N)){write.csv(exp_N, file)}
    }
  )
  
  output$downloadExp_G <- downloadHandler(
    filename = function() {
      paste('exp_G', '.csv', sep='')
    },
    content = function(file) {
      exp_G <- data_G$data
      if(!is.null(exp_G)){write.csv(exp_G, file)}
    }
  )
  
})

