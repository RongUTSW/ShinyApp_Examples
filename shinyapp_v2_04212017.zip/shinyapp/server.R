library(shiny)
library(fields)
library(randomForest)
load("SPRINT_RF_shiny.RData")

# Define server logic required to plot various variables against mpg
shinyServer(function(input, output) {
  
  prediction <- reactive({
    AGE <- as.numeric(input$age)
    GLUR <- as.numeric(input$GLUR)
    UMALCR <- as.numeric(input$UMALCR)
    SCREAT <- as.numeric(input$SCREAT)
    BMI <- as.numeric(input$BMI)
    SBP <- as.numeric(input$SBP)
    CHR <- as.numeric(input$CHR)
    SUB_CLINICALCVD <- as.numeric(input$SUB_CLINICALCVD)
    TRR <- as.numeric(input$TRR)
    DBP <- as.numeric(input$DBP)
    HDL <- as.numeric(input$HDL)
    
    user.input <- c(SBP, DBP, SCREAT, AGE, SUB_CLINICALCVD, CHR, GLUR, HDL, TRR, UMALCR, BMI)
    pseudo.input <- cbind(t(matrix(rep(user.input,9166), nc=9166)),pseudo.post.baseline.BP)
    colnames(pseudo.input)[1:11] <- c("SBP", "DBP", "SCREAT", "AGE", "SUB_CLINICALCVD", "CHR", "GLUR", "HDL", "TRR", "UMALCR", "BMI")
    ##names(pseudo.input)
    ##dim(pseudo.input)
    pred.prob <- predict(RF.model, pseudo.input, type="prob")
    list(pseudo.input=pseudo.input, pred.prob=pred.prob)
  })

  output$risk <- renderPrint({
    pred.result <- prediction()
    pseudo.input <- pred.result[["pseudo.input"]]
    pred.prob <- pred.result[["pred.prob"]]
    summary(pred.prob[,2])
    cat(paste("The best post-baseline BP trajectory can possiblely low this patient's CVD risk to ", min(pred.prob[,2]),".\n\nThe worst post-baseline BP trajectory could result a CVD risk as high as",max(pred.prob[,2]),"for this patient."))
    #dec.SBP <- (pseudo.input[,"SBP.t.c"]<0)
    #w.t <- wilcox.test(pred.prob[,2]~dec.SBP, alternative="greater")$p.value
    #if(w.t<0.05){cat(paste("This model suggests that decreasing SBP post baseline can significantly lower the CVD risk* for patients with such baseline measurements.\n\nPredicted CVD risk is compared between decreasing and increasing SBP trajectories using the Wilcoxon Rank Sum Test (p-value = ", w.t, ").\n\n* This model is trained using NEJM SPRINT Challenge data. The SPRINT primary outcome is defined as the first instance of MI, non-MI ACS, stroke, heart failure, or CVD Death."))}
    #else {cat(paste("This model suggests that decreasing SBP post baseline can NOT significantly lower the CVD risk* for patients with such baseline measurements. \n\nPredicted CVD risk is compared between decreasing and increasing SBP trajectories using the Wilcoxon Rank Sum Test (p-value = ", w.t, ").\n\n* This model is trained using NEJM SPRINT Challenge data. The SPRINT primary outcome is defined as the first instance of MI, non-MI ACS, stroke, heart failure, or CVD Death."))}
  })
  
    output$suggestion <- renderPrint({
    pred.result <- prediction()
    pseudo.input <- pred.result[["pseudo.input"]]
    pred.prob <- pred.result[["pred.prob"]]
    dec.SBP <- (pseudo.input[,"SBP.t.c"]<0)
    w.t <- wilcox.test(pred.prob[,2]~dec.SBP, alternative="greater")$p.value
    if(w.t<0.05){cat(paste("This model suggests that decreasing SBP post baseline can significantly lower the CVD risk* for patients with such baseline measurements.\n\nPredicted CVD risk is compared between decreasing and increasing SBP trajectories using the Wilcoxon Rank Sum Test (p-value = ", w.t, ").\n\n* This model is trained using NEJM SPRINT Challenge data. The SPRINT primary outcome is defined as the first instance of MI, non-MI ACS, stroke, heart failure, or CVD Death."))}
    else {cat(paste("This model suggests that decreasing SBP post baseline can NOT significantly lower the CVD risk* for patients with such baseline measurements. \n\nPredicted CVD risk is compared between decreasing and increasing SBP trajectories using the Wilcoxon Rank Sum Test (p-value = ", w.t, ").\n\n* This model is trained using NEJM SPRINT Challenge data. The SPRINT primary outcome is defined as the first instance of MI, non-MI ACS, stroke, heart failure, or CVD Death."))}
  })
  
  output$RFplot <- renderPlot({
    pred.result <- prediction()
    pseudo.input <- pred.result[["pseudo.input"]]
    pred.prob <- pred.result[["pred.prob"]]
    ##summary(pred.prob)
    par(oma=c( 0,0,0,8))
    tmp <- plot(pseudo.input[,"SBP.t.c"], pred.prob[,"1"] , xlim=c(-1,1), ylim=c(0,1), col=(5+5*pseudo.input[,"DBP.t.c"]), 
                xlab="Hypothetical SBP Slope over Time (Unit: Standard deviation / month)",
                ylab="SPRINT Primary CVD Event Probability", 
                main=paste("Patient: ", input$ID, "(Baseline SBP=", input$SBP, "; DBP=", input$DBP, "; AGE=", input$age, ")", sep=" ")); 
    abline(h=0);abline(v=0);
    ## ,legend.shrink=0.85, legend.width=0.6
    image.plot(legend.only=TRUE, col=(5+3.95*c(-500:500)/500), zlim= range(pseudo.input[,"DBP.t.c"]), legend.lab="The corresponding DBP slope over Time (Unit: Standard deviation / month)", legend.width=0.6, legend.line=3, legend.mar=1)
   })
  
  
  output$text <- renderPrint({
    cat("Question:\n1.Which of the variables measured in SPRINT are relatively more informative for predicting the primary event probability, and which are redundant?\n2.Is it possible to prevent primary event during SPRINT for all patients by managing their blood pressure after baseline in the best way possible?\n\nMethod:\nGiven the large sample size, we think that a random forest model should be a powerful yet clean enough method to start data mining and model interpretation.\n As it turns out this method is sufficient as well, in terms of modeling the SPRINT primary event probability.\nFirstly, we fit simple linear regression to each patients' SBP values over time, and use the time coefficient (SBP.t.c), the p-value of time coefficient (SBP.t.c.p) and the residual standard error (SBP.sigma) to profile each patient's SBP trajectory.\n Similarly, we summarize DBP trajectories over time into DBP.t.c, DBP.t.c.p, and DBP.sigma.\n These six summary statistics of BP follow-up measurements are put into the starting full model for feature selection, along with all baseline variables.\n Categorical baseline variables with multiple levels are put in as separate 0/1 indicators.\n The outcome variable event_primary is used as the label/model output.\nWe perform variable/model selection by setting aside 1700 patients each time as the testing data to assess the prediction accuracy (100 randomly selected from event_primary=1 class; 1600 from event_primary=0 class).\n  Each model is fit and assessed repeatedly using 1000 random partition of training and testing sets.\n The median prediction error rates are used as the main selection criteria.\n The final model is used for ranking the importance of the inputs, and is applied to explore the possibility of preventing primary events during SPRINT.\nFor each patient who had the SPRINT primary event, we evaluate his/her event-prevention possibility by re-calculating the primary event probability distribution under various hypothetical forms of BP trajectory over time.\n That is, we re-calculate the event-developing probabilities by inputting the true baseline measures (including true baseline SBP and DBP) combined with other hypothetical values of BP change summary sextuplets (SBP.t.c, SBP.t.c.p, SBP.sigma, DBP.t.c, DBP.t.c.p, and DBP.sigma).\nTo make sure the hypothetical values are realistic and to preserve the unknown dependency structure between SBP and DBP, we use the estimates of BP summary sextuplet from other patients in SPRINT as pseudo samples from the joint distribution of SBP and DBP, which result in over 9,000 hypothetical summary sextuplets of BP trajectories for each patient under evaluation.\n Note that the intercept of BP regression is not one of the summary sextuplet.\n Therefore, using other patients' sextuplet estimate as the pseudo data is not assuming the patient under evaluation to have different magnitude of BP measurements; the only aspects of BP trajectory being hypothesized here are the direction and magnitude of monthly change, the significance level of linear trend and the variation after detrend.\n\nResult:\n1. Important SPRINT measurements for predicting primary event in order: SBP.sigma (SBP variation over time after detrend; the most informative measure), SBP.t.c.p (significance level of linear trend in SBP), GLUR, AGE, DBP.t.c (time slope in DBP regression), UMALCR, DBP.t.c.p, SCREAT, BMI, SBP.t.c, DBP.sigma, SBP (baseline), CHR, SUB_CLINICALCVD, TRR, DBP (baseline), HDL (the least informative).\n Other baseline variables appear to be relatively redundant for this purpose.\n2. A random forest model containing the 17 inputs listed above can achieve 99.94% median overall prediction accuracy, 100% median accuracy within event_primary=0 class, and 99% median accuracy within event_primary=1 class.\n Dropping any of the last 3 inputs (TRR, DBP, HDL) from the model does not seem to affect the median prediction error rates, but does slightly inflate other quantiles of error rates.\n3. Among the over 500 patients who had primary events, only 21 of them have>=50% chance of developing event under half of 9,000 hypothetical BP trajectories; 158 have median event-developing probability (MEDP)<=0.25; patient S97741 in particular have MEDP of 0.054, for whom the event is highly possible to be prevented, at least within the time frame of SPRINT.\n4. Variables that most important for preventing the primary events via BP control (according to Pearson correlation with MEDP): AGE (r=0.41, p-value<10^(-22)), baseline ratio of SBP/DBP (r=0.38, p-value<1)^(-15)).\n Note that the correlation with any input about only SBP is less strong and less significant.\n")
  })
  
})