##install.packages("shiny")
library(shiny)

# Define UI for miles per gallon application
shinyUI(pageWithSidebar(
  
  # Application title
  headerPanel("Random Forest Model for CVD Risk Prediction"),

  sidebarPanel(
    hr(),
    h4("INPUTS:"),
    hr(),
    textInput("ID", "Patient ID:", "X0001"),
    hr(),
    strong("Baseline Measurements:"),
    textInput("age", "Age:", 55),
    helpText("AGE distribution in training data: min=48, Q1=1, median=67, Q3=75, max=90."),
    textInput("GLUR", "Glucose (mg/dL):", 82),
    helpText("GLUR distribution in training data: min=44, Q1=91, median=97, Q3=105, max=286."),
    textInput("UMALCR", "Mg Urine Alb / (g Creat * 0.01), (unit: mg/g Cr):", 119.54),
    helpText("UMALCR distribution in training data: min=1.36, Q1=5.62, median=9.47, Q3=21.43, max=5000."),
    textInput("SCREAT", "Serum creatinine (mg/dL):", 3.89),
    helpText("SCREAT distribution in training data: min=0.42, Q1=0.86, median=1.01, Q3=1.21, max=4.04."),
    textInput("BMI", "Body mass index (kg/m^2):", 21.31),
    helpText("BMI distribution in training data: min=13.73, Q1=25.90, median=29.04, Q3=32.94, max=69.59."),
    textInput("SBP", "Seated Systolic Blood Pressure  (mm Hg):", 131),
    helpText("SBP distribution in training data: min=72, Q1=130, median=138, Q3=149, max=231."),
    textInput("CHR", "Cholesterol (mg/dL):", 187),
    helpText("CHR distribution in training data: min=71, Q1=161, median=187, Q3=214, max=438."),
    textInput("SUB_CLINICALCVD", "History of clinical CVD: (0-No; 1-Yes)", 0),
    textInput("TRR", "Triglycerides (mg/dL):", 134),
    helpText("TRR distribution in training data: min=23, Q1=77, median=107, Q3=150, max=3340."),
    textInput("DBP", "Seated Diastolic Blood Pressure  (mm Hg):", 76),
    helpText("DBP distribution in training data: min=40, Q1=70, median=78, Q3=86, max=134."),
    textInput("HDL", "HDL-cholesterol direct (mg/dL):", 43),
    helpText("HDL distribution in training data: min=17, Q1=43, median=50, Q3=60, max=161."),
    submitButton("Submit"),
    width=3
  ),
  
  mainPanel(
    p(paste("______________________________________________________________________________Maintainer: Rong Lu <rong.lu@utsw.edu>")),
    hr(),
    h4("OUTPUTS:"),
    hr(),
    verbatimTextOutput("risk"),
    hr(),
    verbatimTextOutput("suggestion"),
    hr(),
    strong("SPRINT Primary CVD Event Risk Prediction:"),
    p(paste("(based on different post-basline BP trajectories)")),
    plotOutput("RFplot", width=800, height=600),
    hr(),
    strong("Details about model building:"),
    verbatimTextOutput("text")
  )
))
